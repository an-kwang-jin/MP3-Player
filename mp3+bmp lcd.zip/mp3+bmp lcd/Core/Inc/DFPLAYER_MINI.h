/*
 * DFPLAYER_MINI.h
 *
 *  Created on: May 16, 2020
 *      Author: controllerstech
 */

#ifndef INC_DFPLAYER_MINI_H_
#define INC_DFPLAYER_MINI_H_

//------experiment1
#include "stdint.h"
//----------------

void Send_cmd (uint8_t cmd, uint8_t Parameter1, uint8_t Parameter2);
void DF_PlayFromStart(void);
void DF_Init (uint8_t volume);
void DF_Next (void);
void DF_Pause (void);
void DF_Previous (void);
void DF_Playback (void);

void Check_Key (void);

//------experiment1
int DF_IsPlaying(void);
int DF_IsPaused(void);
int DF_GetCurrentTrack(void);
//----------------

#endif /* INC_DFPLAYER_MINI_H_ */
