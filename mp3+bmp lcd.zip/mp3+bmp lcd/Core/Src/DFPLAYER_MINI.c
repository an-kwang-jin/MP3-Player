/*
 * DFPLAYER_MINI.c
 *
 *  Created on: May 16, 2020
 *      Author: controllerstech
 */


#include "stm32f1xx_hal.h"
#include "stdio.h"

extern UART_HandleTypeDef huart1;
#define DF_UART &huart1

#define Source      0x02  // TF CARD

#define Previous_Key   GPIO_PIN_8
#define Previous_Port  GPIOC
#define Pause_Key      GPIO_PIN_7
#define Pause_Port     GPIOC
#define Next_Key       GPIO_PIN_6
#define Next_Port      GPIOC

/*************************************** NO CHANGES AFTER THIS *************************************************/

//int ispause =0;
//int isplaying=1;

//------experiment1
int ispause =0;
int isplaying=1;
int currentTrack = 1;
int DF_IsPlaying(void){return isplaying;}
int DF_IsPaused(void){return ispause;}
//----------------

# define Start_Byte 0x7E
# define End_Byte   0xEF
# define Version    0xFF
# define Cmd_Len    0x06
# define Feedback   0x00    //If need for Feedback: 0x01,  No Feedback: 0
void Send_cmd (uint8_t cmd, uint8_t Parameter1, uint8_t Parameter2)
{
	uint16_t Checksum = Version + Cmd_Len + cmd + Feedback + Parameter1 + Parameter2;
	Checksum = 0-Checksum;

	uint8_t CmdSequence[10] = { Start_Byte, Version, Cmd_Len, cmd, Feedback, Parameter1, Parameter2, (Checksum>>8)&0x00ff, (Checksum&0x00ff), End_Byte};

	HAL_UART_Transmit(DF_UART, CmdSequence, 10, HAL_MAX_DELAY);
}

//void DF_PlayFromStart(void)
//{
//  Send_cmd(0x03,0x00,0x01);
//  //----experiment---
//  currentTrack = 1;
//  //----------------
//  HAL_Delay(200);
//}


void DF_Init (uint8_t volume)
{
	Send_cmd(0x3F, 0x00, Source);
	HAL_Delay(200);
	Send_cmd(0x06, 0x00, volume);
	HAL_Delay(500);
}

//void DF_Next (void)
//{
//	Send_cmd(0x01, 0x00, 0x00);
//	HAL_Delay(200);
//}
//
void DF_Pause (void)
{
	Send_cmd(0x0E, 0, 0);
	HAL_Delay(200);
}

//void DF_Previous (void)
//{
//	Send_cmd(0x02, 0, 0);
//	HAL_Delay(200);
//}
void DF_PlayFromStart(void) {
    Send_cmd(0x03, 0x00, 0x01);  // 첫 번째 트랙 재생
    currentTrack = 1;
    HAL_Delay(200);
}

void DF_Next(void) {
    if (currentTrack < 12) {  // 최대 트랙 수는 12
        Send_cmd(0x01, 0x00, 0x00);
        currentTrack++;
    }
    HAL_Delay(200);
}

void DF_Previous(void) {
    if (currentTrack > 1) {  // 최소 트랙은 1
        Send_cmd(0x02, 0x00, 0x00);
        currentTrack--;
    }
    HAL_Delay(200);
}
void DF_Playback (void)
{
	Send_cmd(0x0D, 0, 0);
	HAL_Delay(200);
}

void Check_Key (void)
{
	if (HAL_GPIO_ReadPin(Pause_Port, Pause_Key)== GPIO_PIN_RESET)
	{
		while (HAL_GPIO_ReadPin(Pause_Port, Pause_Key)== GPIO_PIN_RESET);
		if (isplaying)
		{
			ispause = 1;
			isplaying = 0;
			DF_Pause();
			//displayImage(MusicBmpFiles[currentMusicIndex]);
		}

		else if (ispause)
		{
			isplaying = 1;
			ispause = 0;
			DF_Playback();
			//displayImage(MusicBmpFiles[currentMusicIndex]);
		}
	}

	if (HAL_GPIO_ReadPin(Previous_Port, Previous_Key)== GPIO_PIN_RESET)
	{
		//HAL_Delay(20);
		while (HAL_GPIO_ReadPin(Previous_Port, Previous_Key)== GPIO_PIN_RESET);
		DF_Previous();
		//displayImage(MusicBmpFiles[currentMusicIndex--]);
	}

	if (HAL_GPIO_ReadPin(Next_Port, Next_Key)== GPIO_PIN_RESET)
	{
		//HAL_Delay(20);
		while (HAL_GPIO_ReadPin(Next_Port, Next_Key)== GPIO_PIN_RESET);
		DF_Next();
		//displayImage(MusicBmpFiles[currentMusicIndex++]);
	}
}

int DF_GetCurrentTrack(void) {
    return currentTrack;
}













